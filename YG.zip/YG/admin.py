from django.contrib import admin
from .models import *
from .models import GraphicSoftware
# Register your models here.

admin.site.register(StudentUser)
admin.site.register(GraphicSoftware)
admin.site.register(Card)
admin.site.register(Feedback)

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)