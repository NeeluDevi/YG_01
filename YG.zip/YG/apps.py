from django.apps import AppConfig


class YgConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'YG'
